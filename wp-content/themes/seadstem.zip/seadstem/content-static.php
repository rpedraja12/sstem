

<div class="container">
    <div class="row mb-3">
        <div class="col-xs-12">
            <h1 ><?php echo get_the_title(); ?></h1>
        </div>
    </div>
</div>

<?php echo get_the_content(); ?>
