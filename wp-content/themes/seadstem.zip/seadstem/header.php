<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8"/>
        <title><?php wp_title(); ?></title>
        <script type="text/javascript">
            var templateUrl = "<?php echo get_template_directory_uri(); ?>";
        </script>
        <?php wp_head(); ?>

    </head>
    <body <?php body_class(); ?>>
        <div class="container">
            <div class="d-none d-sm-block">
                <div class="row" id="header-nav">
                    <div class="col-xs-12 col-sm-4 pt-4" id="header-left">
                        <?php wp_nav_menu(['theme_location' => 'left-header']); ?>
                    </div>
                    <div class="col-xs-12 col-sm-3 offset-sm-1">
                        <?php
                        $custom_logo_id = get_theme_mod('custom_logo');
                        $logo = wp_get_attachment_image_src($custom_logo_id, 'full');
                        if (has_custom_logo()) {
                            echo '<img src="' . esc_url($logo[0]) . '" class="img-fluid" id="logo">';
                        } else {
                            echo '<h1>' . get_bloginfo('name') . '</h1>';
                        }
                        ?>
                    </div>
                    <div class="col-xs-12 col-sm-4 pt-4" id="header-right">
                        <?php get_sidebar(); ?>
                        <div class="clearfix"></div>
                        <?php wp_nav_menu(['theme_location' => 'right-header']); ?>
                    </div>

                </div>
            </div>
            <div class="d-block d-sm-none">
                <div id="header-nav-small">
                    <div class="dropdown" style="display: inline-block">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="fa fa-align-justify"></span>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <?php wp_nav_menu(['theme_location' => 'collapsed-header']); ?>
                        </div>
                    </div>

                    ronald pedraja
                </div>
            </div>


        </div>

