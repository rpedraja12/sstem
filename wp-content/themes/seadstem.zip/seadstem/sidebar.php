<div id="widget-side-bars" class="widgets-area">
    <?php dynamic_sidebar('widget-container-1');?>
</div>