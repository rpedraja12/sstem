=== Plugin Name ===
Contributors: saturngod
Tags: zawgyi,Myanmar,font
Requires at least: 2.5
Tested up to: 4.5.2
Stable tag: 2.1.1

In this days, many Myanmar websites are using Zawgyi Font and wordpress. However, we have a problem. We can't read Myanmarsar on mobile device or no font. This plugin will help to support ,to see your websites with Myanmarsar on mobile.

== Description ==

In this days, many Myanmar websites are using Zawgyi Font and wordpress. However, we have a problem. We can't read Myanmarsar on mobile device or no font. This plugin will help to support ,to see your websites with Myanmarsar on mobile. This plugin support iPhone,iPodTouch,iPad and Android to see Zawgyi font.

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `zawgyi-embed` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. WP Admin -> Settings -> Zawgyi Embed

== Frequently Asked Questions ==

= How to get support =

send my mail saturngod {at} gmail dot com

== Screenshots ==

== Changelog ==
= 1.1.3 =
Fixed Android

= 1.1.2 =
Fixed Files

= 1.1.1 =
Fixed iPhone font

= 1.1 =
Fixed Chrome

= 1.0 =
Support Android

= 0.9 =
* Support iPhone